package com.example.formularioreparaciondiegoconstanza;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    private TextView MNombres;
    private TextView MTelefono;
    private TextView MCorreo;
    private TextView MDirección;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        MNombres = (TextView) findViewById(R.id.MNombres);
        MTelefono = (TextView) findViewById(R.id.MTelefono);
        MCorreo = (TextView) findViewById(R.id.MCorreo);
        MDirección = (TextView) findViewById(R.id.MDirección);


        String datoN = getIntent().getStringExtra("datoN");
        MNombres.setText("Hola, mucho gusto " + datoN);

        String datoT =getIntent().getStringExtra("datoT");
        MTelefono.setText("Tu número de telefono es: " + datoT);

        String datoC =getIntent().getStringExtra("datoC");
        MCorreo.setText("Tu correo electrónico es: " + datoC);

        String datoD =getIntent().getStringExtra("datoD");
        MDirección.setText("Y tu dirección es:" + datoD);
    }

    public void Regresar(View View){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
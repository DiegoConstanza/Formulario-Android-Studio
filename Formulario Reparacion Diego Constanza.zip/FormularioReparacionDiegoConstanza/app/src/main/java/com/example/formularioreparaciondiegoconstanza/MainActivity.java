package com.example.formularioreparaciondiegoconstanza;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText Nombres;
    private EditText Telefono;
    private EditText Correo;
    private EditText Dirección;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Nombres = (EditText)findViewById(R.id.Nombres);
        Telefono = (EditText) findViewById(R.id.Telefono);
        Correo = (EditText) findViewById(R.id.Correo);
        Dirección = (EditText) findViewById(R.id.Dirección);
    }

    public void Enviar(View View){
        Intent i = new Intent(this, MainActivity2.class);
        i.putExtra("datoN", Nombres.getText().toString());
        i.putExtra("datoT", Telefono.getText().toString());
        i.putExtra("datoC", Correo.getText().toString());
        i.putExtra("datoD", Dirección.getText().toString());
        startActivity(i);
    }
}